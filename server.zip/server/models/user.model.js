const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const { Schema } = mongoose;

const UserSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  surname: {
    type: String,
    required: true,
  },
  login: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  country: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  contact: {
    contactValue: {
      type: String
    },
    contactType: {
      type: String
    }
  }
}, { versionKey: false });

function hashPassword(next) {
  if (!this.isModified('password')) return next();
  bcrypt.hash(this.password, 10, (err, hash) => {
    if (err) {
      next(err);
    }
    this.password = hash;
    next();
  });
  return 1;
}

UserSchema.pre('save', hashPassword);

function checkPassword(passwordToCheck) {
  return bcrypt.compareSync(passwordToCheck, this.password);
}

UserSchema.methods.checkPassword = checkPassword;

const User = mongoose.model('user', UserSchema);

module.exports = User;
