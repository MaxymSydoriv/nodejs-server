const mongoose = require('mongoose');

const { Schema } = mongoose;

const CitySchema = new Schema({
  city: {
    type: String,
  },
  city_ascii: {
    type: String,
  },
  lat: {
    type: Number,
  },
  lng: {
    type: Number,
  },
  country: {
    type: String,
  }, 
  iso2: {
    type: String,
  },
  iso3: {
    type: String,
  },
  admin_name: {
    type: String,
  },
  capital: {
    type: String,
  },
  id: {
    type: Number,
  },
}, { versionKey: false });

const City = mongoose.model('city', CitySchema);

module.exports = City;