const cors = require('cors');
const bodyParser = require('body-parser');
const passport = require('./config/passport');
require('./config/mongoose');
const express = require('express');
const config = require('./config/config');

const { hostname, port } = config;

const app = express();

app.use(cors())
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/authenticate', require('./routes/authenticate.route'));
app.use('/cities', require('./routes/city.route'));
app.use('/users', passport.authenticate('jwt', {
  session: false,
}), require('./routes/user.route'));


app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});