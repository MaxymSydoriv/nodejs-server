const reducePropsToObject = (propsArray, source) => propsArray.reduce((obj, el) => {
  if (source[el]) {
    return {
      ...obj,
      [el]: source[el],
    };
  }
  return {
    ...obj,
  };
}, {});

module.exports = {
  reducePropsToObject
};