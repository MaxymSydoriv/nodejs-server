module.exports = {
  hostname: process.argv[2] || process.env.HOSTNAME || '127.0.0.1',
  port: process.argv[3] || 3000,
  arrKeys: ['login', 'password', 'name', 'surname', 'city', 'country', 'contact'],
  JWT_SECRET: 'my_secret_key_for_Angular_logination',
  existenceToken: '24h'
};
