const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://m001-student:m001-mongodb-basics@clustero-4pq9s.mongodb.net/tasksdb', { useNewUrlParser: true });
module.exports = mongoose;