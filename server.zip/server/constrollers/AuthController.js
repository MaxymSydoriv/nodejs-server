const jwt = require('jsonwebtoken');
const User = require('../models/user.model');
const helpers = require('../utils/helpers');
const {
  JWT_SECRET,
  arrKeys,
  existenceToken
} = require('../config/config');

const signup = async (req, res) => {
  const parameters = helpers.reducePropsToObject(arrKeys, req.body);
  const newUser = User({
    ...parameters
  });

  let savedUser;
  try {
    const doc = await User.findOne({ "login": parameters.login });

    if (!doc) {
      savedUser = await newUser.save();

      const token = jwt.sign({ id: savedUser._id }, JWT_SECRET, {
        expiresIn: existenceToken
      })
      res.status(201).json({
        signed_user: savedUser,
        token: token
      });
    } else {
      res.status(403).json({
        errorMessage: `Login "${parameters.login}" already exists`
      });
    }
  } catch (err) {
    if (savedUser) {
      User.findByIdAndDelete(savedUser._id);
    }
    res.status(500).json({
      errorMessage: err,
    });
  }

};

const signin = async (req, res) => {
  const { login, password } = req.body;

  try {
    const user = await User.findOne({ login }).exec();

    if (!user) {
      res.status(404).json({
        errorMessage: `User "${login}" not found`,
      });

      return 0;
    }
    if (user.checkPassword(String(password))) {
      res.json({
        token: jwt.sign({ id: user._id }, JWT_SECRET, {
          expiresIn: existenceToken
        })
      });

      return 0;
    }

    res.status(400).json({
      errorMessage: 'Passwords don\'t match',
    });
  } catch (err) {
    res.status(500).json({
      errorMessage: err
    });
  }

};

module.exports = {
  signin,
  signup
};
