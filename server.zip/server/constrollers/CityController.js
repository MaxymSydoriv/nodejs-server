const City = require('../models/city.model');

const getCountries = async (req, res) => {

  try {
    const countries = await City.distinct('country').exec();

    if (!countries) {
      res.status(404).json({
        err: 'Countries not found',
      });

      return 0;
    }

    res.json(countries);
  } catch (err) {
    res.status(500).json({
      err,
    });
  }
};

const getCities = async (req, res) => {
  const { country } = req.body;
  
  try {
    const cities = await City.find({country}).exec();

    if (cities === undefined) {
      res.status(404).json({
        errorMessage: 'Countries not found',
      });

      return 0;
    }

    res.json(cities);
  } catch (err) {
    res.status(500).json({
      err,
    });
  }
};


module.exports = {
  getCountries,
  getCities
};
