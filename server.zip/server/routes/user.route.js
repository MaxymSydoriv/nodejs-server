const express = require('express');
const controller = require('../constrollers/UserController');

const router = express.Router();

router.route('/').put(controller.updateOne);

router.route('/:id')
  .get(controller.getOne)
  .delete (controller.deleteOne);



module.exports = router;