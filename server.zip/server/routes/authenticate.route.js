const express = require('express');
const controller = require('../constrollers/AuthController');

const router = express.Router();

router.post('/login', controller.signin);
router.post('/signup', controller.signup);

module.exports = router;



