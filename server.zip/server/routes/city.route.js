const express = require('express');
const controller = require('../constrollers/CityController');

const router = express.Router();

router.route('/')
  .get(controller.getCountries)
  .post(controller.getCities)

module.exports = router;